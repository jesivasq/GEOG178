package Evacuation;

public abstract class Disaster{
	// abstract class
	// super class for Flood, Wildfire
	
	Polygon area;
	
}
