package Evacuation;

public class Wildfire extends Disaster {

}
