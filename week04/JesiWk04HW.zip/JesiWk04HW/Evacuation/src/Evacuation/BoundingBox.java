package Evacuation;

public class BoundingBox {
	Polygon area;
}
