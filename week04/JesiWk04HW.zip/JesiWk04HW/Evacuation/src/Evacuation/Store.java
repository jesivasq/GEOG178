package Evacuation;

public class Store extends Building {

	public Store(Point location) {
		type = "Store";
		this.location = location;
	}
	
}
