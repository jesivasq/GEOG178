package Evacuation;

public class Flood extends Disaster{

}
