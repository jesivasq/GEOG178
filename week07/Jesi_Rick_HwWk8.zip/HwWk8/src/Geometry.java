
public interface Geometry {
	public double getLength();
	public double getArea();
}
