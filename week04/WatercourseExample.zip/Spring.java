package edu.geog.ucsb.week5;

//Very simple class for springs
public class Spring {
	private String name;

	public Spring(String name){
		this.name = name;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
