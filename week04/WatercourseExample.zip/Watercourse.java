package edu.geog.ucsb.week5;

// Very simple class for watercourses

public class Watercourse {
	private double length;
	
	public Watercourse(int length){
		this.length = length;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}
	
}

