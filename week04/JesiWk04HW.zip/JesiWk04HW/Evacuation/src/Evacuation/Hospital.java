package Evacuation;

public class Hospital extends Building{

	public Hospital(Point location) {
		type = "Hospital";
		this.location = location;
	}
}
