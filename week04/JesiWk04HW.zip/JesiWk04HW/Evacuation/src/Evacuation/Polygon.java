package Evacuation;

public class Polygon {

}
