package hwWk7;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new HwWk7();
			}
		});

	}

}
