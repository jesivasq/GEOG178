package Evacuation;

public class Farm extends Building {

	
	public Farm(Point location) {
		this.type = "Farm";
		this.location = location;
	}
}
